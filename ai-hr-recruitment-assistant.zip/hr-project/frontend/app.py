"""
AI HR Recruitment Assistant — Streamlit Frontend
===================================================
Talks to the FastAPI backend (backend/main.py) over HTTP — real
frontend/backend separation, matching the project's tech stack
(Frontend/Dashboard: Streamlit, Backend/API: FastAPI).

Run it (after the backend is already running on port 8000):
    cd frontend
    pip install -r requirements.txt --break-system-packages
    streamlit run app.py
"""

import streamlit as st
import requests

API_BASE = "http://localhost:8000/api"

st.set_page_config(page_title="AI HR Recruitment Assistant", layout="wide")


def api_get(path):
    try:
        r = requests.get(f"{API_BASE}{path}", timeout=10)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        st.error("⚠️ Cannot reach the backend. Start it first with:\n\n"
                  "`cd backend && uvicorn main:app --reload --port 8000`")
        st.stop()
    except requests.exceptions.HTTPError as e:
        st.error(f"API error: {e}")
        st.stop()


def api_post(path, json_body=None, files=None, data=None):
    try:
        r = requests.post(f"{API_BASE}{path}", json=json_body, files=files, data=data, timeout=30)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        st.error("⚠️ Cannot reach the backend. Start it first with:\n\n"
                  "`cd backend && uvicorn main:app --reload --port 8000`")
        st.stop()
    except requests.exceptions.HTTPError as e:
        st.error(f"API error: {e.response.text if e.response is not None else e}")
        st.stop()


st.sidebar.title("AI HR Recruitment Assistant")
page = st.sidebar.radio(
    "Navigate",
    ["Overview (Dashboard)", "Resume Parser Agent", "Candidate Chatbot", "Job Description"],
)

# ---------------------------- DASHBOARD --------------------------------
if page == "Overview (Dashboard)":
    st.title("📊 HR Dashboard — Candidate Pipeline")

    data = api_get("/dashboard")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Resumes Processed", data["resumes_processed"])
    c2.metric("Shortlisted", data["shortlisted"])
    c3.metric("Interviews Scheduled", data["interviews_scheduled"])
    c4.metric("Avg. Match Score", f"{data['avg_match_score']}%")

    st.subheader("Top Ranked Candidates")
    if data["top_candidates"]:
        import pandas as pd
        df = pd.DataFrame([
            {
                "Candidate": c["name"],
                "JD Match Score": f"{c['jd_match_score']}%",
                "Status": c["status"],
                "Matched Skills": ", ".join(c["matched_skills"]),
            }
            for c in data["top_candidates"]
        ])
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No candidates parsed yet — go to **Resume Parser Agent** to add one.")

    st.subheader("Agent Activity Log")
    if data["activity_log"]:
        for entry in data["activity_log"]:
            st.markdown(f"**{entry['time']}** · *{entry['agent']}* — {entry['message']}")
    else:
        st.caption("No agent activity yet.")

    if st.button("🔄 Refresh"):
        st.rerun()

# ------------------------ JOB DESCRIPTION --------------------------------
elif page == "Job Description":
    st.title("📋 Job Requisition")
    current = api_get("/jd/latest")
    st.caption("New candidates are matched against this JD.")

    title = st.text_input("Role title", current["text"] and current.get("title", "Untitled Role"))
    text = st.text_area("Job description text", current["text"], height=150)

    if st.button("Save Job Description", type="primary"):
        api_post("/jd", json_body={"title": title, "text": text})
        st.success("Job description updated. New matches will use this JD.")

# ------------------------ RESUME PARSER AGENT ---------------------------
elif page == "Resume Parser Agent":
    st.title("🧾 Resume Parser Agent")

    col1, col2 = st.columns(2)
    with col1:
        candidate_name = st.text_input("Candidate name", "Candidate A")
        uploaded_file = st.file_uploader(
            "Upload resume (PDF / DOCX / TXT)", type=["pdf", "docx", "txt"]
        )
        pasted_text = st.text_area("...or paste resume text directly", height=150)
        run_btn = st.button("Run Resume Parser Agent", type="primary")

    result = None
    if run_btn:
        if uploaded_file is not None:
            files = {"file": (uploaded_file.name, uploaded_file.getvalue())}
            data = {"candidate_name": candidate_name}
            result = api_post("/resumes/parse-file", files=files, data=data)
        elif pasted_text.strip():
            result = api_post("/resumes/parse-text", json_body={
                "candidate_name": candidate_name, "resume_text": pasted_text
            })
        else:
            st.warning("Upload a resume file or paste resume text first.")

    with col2:
        if result:
            st.metric("JD Match Score", f"{result['jd_match_score']}%")
            badge = {"Shortlisted": "✅", "On Hold": "🟡", "Rejected": "🔴"}
            st.write(f"{badge.get(result['status'], '')} **Status:** {result['status']}")
            st.json(result)
        else:
            try:
                existing = api_get(f"/candidates/{candidate_name}")
                st.metric("JD Match Score", f"{existing['jd_match_score']}%")
                st.write(f"**Status:** {existing['status']}")
                st.json(existing)
            except SystemExit:
                pass

# --------------------------- CANDIDATE CHATBOT ---------------------------
elif page == "Candidate Chatbot":
    st.title("💬 Candidate Assistant Chat")
    st.caption("Communication Agent — answers grounded in the HR FAQ knowledge base.")

    candidate_name = st.text_input("Chatting as candidate", "Candidate A")

    try:
        history = api_get(f"/chatbot/history/{candidate_name}")
    except SystemExit:
        history = []

    for msg in history:
        with st.chat_message(msg["role"]):
            st.write(msg["message"])

    question = st.chat_input("Type your message...")
    if question:
        api_post("/chatbot", json_body={"candidate_name": candidate_name, "message": question})
        st.rerun()
