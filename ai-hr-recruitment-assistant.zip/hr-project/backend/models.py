"""Pydantic schemas used by the FastAPI backend."""

from pydantic import BaseModel
from typing import List, Optional


class JDCreate(BaseModel):
    title: str = "Untitled Role"
    text: str


class ResumeTextIn(BaseModel):
    candidate_name: str
    resume_text: str


class CandidateOut(BaseModel):
    id: int
    name: str
    email: str
    phone: str
    total_experience_years: float
    skills: List[str]
    matched_skills: List[str]
    missing_skills: List[str]
    jd_match_score: int
    status: str

    class Config:
        from_attributes = True


class ScheduleIn(BaseModel):
    candidate_name: str
    preferred_time: Optional[str] = None


class ChatIn(BaseModel):
    candidate_name: str
    message: str


class ChatOut(BaseModel):
    reply: str


class ActivityOut(BaseModel):
    time: str
    agent: str
    message: str


class DashboardOut(BaseModel):
    resumes_processed: int
    shortlisted: int
    interviews_scheduled: int
    avg_match_score: int
    pipeline: dict
    top_candidates: List[CandidateOut]
    activity_log: List[ActivityOut]
