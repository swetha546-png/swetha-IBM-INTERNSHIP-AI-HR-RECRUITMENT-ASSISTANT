"""Database setup — SQLite via SQLAlchemy (swap the URL for PostgreSQL in production)."""

from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
import datetime as dt

DATABASE_URL = "sqlite:///./hr_assistant.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class JobDescription(Base):
    __tablename__ = "job_descriptions"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, default="Untitled Role")
    text = Column(Text)
    created_at = Column(DateTime, default=dt.datetime.utcnow)


class Candidate(Base):
    __tablename__ = "candidates"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    email = Column(String, default="not found")
    phone = Column(String, default="not found")
    total_experience_years = Column(Float, default=0.0)
    skills = Column(Text, default="")          # comma-separated
    matched_skills = Column(Text, default="")
    missing_skills = Column(Text, default="")
    jd_match_score = Column(Integer, default=0)
    status = Column(String, default="Pending")
    resume_text = Column(Text, default="")
    created_at = Column(DateTime, default=dt.datetime.utcnow)


class Interview(Base):
    __tablename__ = "interviews"
    id = Column(Integer, primary_key=True, index=True)
    candidate_name = Column(String, index=True)
    scheduled_time = Column(String)
    panel = Column(String, default="Engineering Team")
    status = Column(String, default="Scheduled")
    created_at = Column(DateTime, default=dt.datetime.utcnow)


class ActivityLog(Base):
    __tablename__ = "activity_log"
    id = Column(Integer, primary_key=True, index=True)
    agent = Column(String)
    message = Column(Text)
    created_at = Column(DateTime, default=dt.datetime.utcnow)


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id = Column(Integer, primary_key=True, index=True)
    candidate_name = Column(String, index=True)
    role = Column(String)       # "user" | "assistant"
    message = Column(Text)
    created_at = Column(DateTime, default=dt.datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
