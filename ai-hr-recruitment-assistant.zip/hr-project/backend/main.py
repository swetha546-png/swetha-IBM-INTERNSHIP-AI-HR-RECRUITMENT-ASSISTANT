"""
AI HR Recruitment Assistant — FastAPI Backend
================================================
Acts as the Planner/Orchestrator Agent: exposes REST endpoints that the
Streamlit frontend (or anything else) calls, delegates work to the
specialised agents in agents.py, and logs every step to the database.

Run it:
    cd backend
    pip install -r requirements.txt --break-system-packages
    uvicorn main:app --reload --port 8000

Interactive API docs: http://localhost:8000/docs
"""

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import desc

import database as db
import models as schemas
import agents

app = FastAPI(title="AI HR Recruitment Assistant API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

db.init_db()


def log(session: Session, agent: str, message: str):
    session.add(db.ActivityLog(agent=agent, message=message))
    session.commit()


def get_or_create_default_jd(session: Session) -> db.JobDescription:
    jd = session.query(db.JobDescription).order_by(desc(db.JobDescription.id)).first()
    if jd is None:
        jd = db.JobDescription(
            title="Software Engineer",
            text=("Looking for a Software Engineer with Python, REST API, "
                  "SQL, AWS and Docker experience. 2+ years preferred."),
        )
        session.add(jd)
        session.commit()
        session.refresh(jd)
    return jd


# ------------------------------------------------------------------
# Job Description endpoints
# ------------------------------------------------------------------

@app.post("/api/jd")
def set_job_description(payload: schemas.JDCreate, session: Session = Depends(db.get_db)):
    jd = db.JobDescription(title=payload.title, text=payload.text)
    session.add(jd)
    session.commit()
    session.refresh(jd)
    log(session, "Planner / Orchestrator Agent", f"New job requisition set: {payload.title}")
    return {"id": jd.id, "title": jd.title, "text": jd.text}


@app.get("/api/jd/latest")
def get_latest_jd(session: Session = Depends(db.get_db)):
    jd = get_or_create_default_jd(session)
    return {"id": jd.id, "title": jd.title, "text": jd.text}


# ------------------------------------------------------------------
# Resume Parser + Screening & Matching (file upload OR raw text)
# ------------------------------------------------------------------

def _process_resume(session: Session, candidate_name: str, raw_text: str):
    jd = get_or_create_default_jd(session)

    parsed = agents.parse_resume(raw_text)
    log(session, "Resume Parser Agent",
        f"Parsed resume for {candidate_name} — found {len(parsed['skills'])} skills.")

    match = agents.compute_match_score(parsed["skills"], jd.text)
    log(session, "Screening & Matching Agent",
        f"{candidate_name} scored {match['jd_match_score']}% -> {match['status']}.")

    existing = session.query(db.Candidate).filter_by(name=candidate_name).first()
    if existing is None:
        existing = db.Candidate(name=candidate_name)
        session.add(existing)

    existing.email = parsed["email"]
    existing.phone = parsed["phone"]
    existing.total_experience_years = parsed["total_experience_years"]
    existing.skills = ",".join(parsed["skills"])
    existing.matched_skills = ",".join(match["matched_skills"])
    existing.missing_skills = ",".join(match["missing_skills"])
    existing.jd_match_score = match["jd_match_score"]
    existing.status = match["status"]
    existing.resume_text = raw_text
    session.commit()
    session.refresh(existing)

    if match["status"] == "Shortlisted":
        slot = agents.propose_interview_slot()
        session.add(db.Interview(candidate_name=candidate_name, **slot))
        session.commit()
        log(session, "Scheduling Agent",
            f"Booked interview for {candidate_name} on {slot['scheduled_time']}.")

    return existing


@app.post("/api/resumes/parse-file")
async def parse_resume_file(
    candidate_name: str = Form(...),
    file: UploadFile = File(...),
    session: Session = Depends(db.get_db),
):
    data = await file.read()
    try:
        raw_text = agents.extract_text_from_bytes(file.filename, data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not raw_text.strip():
        raise HTTPException(status_code=400, detail="Could not extract text from file.")
    candidate = _process_resume(session, candidate_name, raw_text)
    return _candidate_to_dict(candidate)


@app.post("/api/resumes/parse-text")
def parse_resume_text(payload: schemas.ResumeTextIn, session: Session = Depends(db.get_db)):
    candidate = _process_resume(session, payload.candidate_name, payload.resume_text)
    return _candidate_to_dict(candidate)


# ------------------------------------------------------------------
# Candidates
# ------------------------------------------------------------------

def _candidate_to_dict(c: db.Candidate) -> dict:
    return {
        "id": c.id,
        "name": c.name,
        "email": c.email,
        "phone": c.phone,
        "total_experience_years": c.total_experience_years,
        "skills": [s for s in c.skills.split(",") if s],
        "matched_skills": [s for s in c.matched_skills.split(",") if s],
        "missing_skills": [s for s in c.missing_skills.split(",") if s],
        "jd_match_score": c.jd_match_score,
        "status": c.status,
    }


@app.get("/api/candidates")
def list_candidates(session: Session = Depends(db.get_db)):
    candidates = session.query(db.Candidate).order_by(desc(db.Candidate.jd_match_score)).all()
    return [_candidate_to_dict(c) for c in candidates]


@app.get("/api/candidates/{name}")
def get_candidate(name: str, session: Session = Depends(db.get_db)):
    c = session.query(db.Candidate).filter_by(name=name).first()
    if not c:
        raise HTTPException(status_code=404, detail="Candidate not found")
    return _candidate_to_dict(c)


# ------------------------------------------------------------------
# Scheduling Agent
# ------------------------------------------------------------------

@app.post("/api/interviews/schedule")
def schedule_interview(payload: schemas.ScheduleIn, session: Session = Depends(db.get_db)):
    candidate = session.query(db.Candidate).filter_by(name=payload.candidate_name).first()
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")

    slot = agents.propose_interview_slot(payload.preferred_time)
    interview = db.Interview(candidate_name=payload.candidate_name, **slot)
    session.add(interview)
    session.commit()
    log(session, "Scheduling Agent",
        f"Booked interview for {payload.candidate_name} on {slot['scheduled_time']}.")
    return slot


@app.get("/api/interviews")
def list_interviews(session: Session = Depends(db.get_db)):
    rows = session.query(db.Interview).order_by(desc(db.Interview.id)).all()
    return [
        {
            "candidate_name": r.candidate_name,
            "scheduled_time": r.scheduled_time,
            "panel": r.panel,
            "status": r.status,
        }
        for r in rows
    ]


# ------------------------------------------------------------------
# Communication Agent (chatbot)
# ------------------------------------------------------------------

@app.post("/api/chatbot", response_model=schemas.ChatOut)
def chatbot(payload: schemas.ChatIn, session: Session = Depends(db.get_db)):
    candidate = session.query(db.Candidate).filter_by(name=payload.candidate_name).first()
    status = candidate.status if candidate else None

    reply = agents.chatbot_reply(payload.message, status)

    session.add(db.ChatMessage(candidate_name=payload.candidate_name, role="user", message=payload.message))
    session.add(db.ChatMessage(candidate_name=payload.candidate_name, role="assistant", message=reply))
    session.commit()
    log(session, "Communication Agent", f"Replied to {payload.candidate_name}'s query.")
    return {"reply": reply}


@app.get("/api/chatbot/history/{candidate_name}")
def chat_history(candidate_name: str, session: Session = Depends(db.get_db)):
    rows = (
        session.query(db.ChatMessage)
        .filter_by(candidate_name=candidate_name)
        .order_by(db.ChatMessage.id)
        .all()
    )
    return [{"role": r.role, "message": r.message} for r in rows]


# ------------------------------------------------------------------
# Dashboard
# ------------------------------------------------------------------

@app.get("/api/dashboard")
def dashboard(session: Session = Depends(db.get_db)):
    candidates = session.query(db.Candidate).all()
    total = len(candidates)
    shortlisted = sum(1 for c in candidates if c.status == "Shortlisted")
    on_hold = sum(1 for c in candidates if c.status == "On Hold")
    rejected = sum(1 for c in candidates if c.status == "Rejected")
    avg_score = round(sum(c.jd_match_score for c in candidates) / total) if total else 0

    interviews_count = session.query(db.Interview).count()

    top = (
        session.query(db.Candidate)
        .order_by(desc(db.Candidate.jd_match_score))
        .limit(5)
        .all()
    )

    logs = (
        session.query(db.ActivityLog)
        .order_by(desc(db.ActivityLog.id))
        .limit(10)
        .all()
    )

    return {
        "resumes_processed": total,
        "shortlisted": shortlisted,
        "on_hold": on_hold,
        "rejected": rejected,
        "interviews_scheduled": interviews_count,
        "avg_match_score": avg_score,
        "top_candidates": [_candidate_to_dict(c) for c in top],
        "activity_log": [
            {"time": l.created_at.strftime("%H:%M:%S"), "agent": l.agent, "message": l.message}
            for l in logs
        ],
    }


@app.get("/")
def root():
    return {"status": "ok", "message": "AI HR Recruitment Assistant API is running. See /docs"}
