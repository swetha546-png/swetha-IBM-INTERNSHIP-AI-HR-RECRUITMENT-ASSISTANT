"""
Agentic AI logic — each function below represents one specialised agent
from the project's multi-agent architecture. The FastAPI routes in
main.py act as the Planner/Orchestrator: they call these agents in
sequence and log every step to the activity_log table.
"""

import re
import io
import random
import datetime as dt

SKILL_KEYWORDS = [
    "python", "java", "javascript", "react", "node", "sql", "aws", "docker",
    "kubernetes", "rest api", "flask", "django", "fastapi", "machine learning",
    "nlp", "git", "agile", "scrum", "langchain", "pandas", "excel", "html",
    "css", "typescript", "postgresql", "mongodb", "azure", "gcp",
]

FAQ_KB = [
    {"q": ["status", "application"],
     "a": "Your application status is visible on the Candidates tab. Once "
          "screening is complete you'll get an email with your result."},
    {"q": ["interview", "schedule", "when"],
     "a": "Interviews are scheduled automatically once you're shortlisted. "
          "You'll receive a calendar invite by email."},
    {"q": ["reschedule"],
     "a": "Yes — just reply with your preferred time and the Scheduling "
          "Agent will coordinate with the panel automatically."},
    {"q": ["result", "hear back", "response time"],
     "a": "Results are typically shared within 5 working days after your "
          "interview."},
    {"q": ["document", "documents needed"],
     "a": "Please keep your government ID, latest resume, and educational "
          "certificates ready for the interview round."},
]


# ------------------------------------------------------------------
# 1. Resume Parser Agent
# ------------------------------------------------------------------

def extract_text_from_bytes(filename: str, data: bytes) -> str:
    name = filename.lower()

    if name.endswith(".pdf"):
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(data))
        return "\n".join(page.extract_text() or "" for page in reader.pages)

    if name.endswith(".docx"):
        import docx
        d = docx.Document(io.BytesIO(data))
        return "\n".join(p.text for p in d.paragraphs)

    return data.decode("utf-8", errors="ignore")


def parse_resume(text: str) -> dict:
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
    phone_match = re.search(r"(\+?\d[\d\-\s]{8,}\d)", text)

    text_lower = text.lower()
    found_skills = sorted({kw for kw in SKILL_KEYWORDS if kw in text_lower})

    exp_matches = re.findall(r"(\d+(?:\.\d+)?)\s*\+?\s*years?", text_lower)
    experience_years = max((float(x) for x in exp_matches), default=0.0)

    return {
        "email": email_match.group(0) if email_match else "not found",
        "phone": phone_match.group(0) if phone_match else "not found",
        "total_experience_years": experience_years,
        "skills": found_skills,
    }


# ------------------------------------------------------------------
# 2. Screening & Matching Agent
# ------------------------------------------------------------------

def compute_match_score(candidate_skills: list, jd_text: str) -> dict:
    jd_lower = jd_text.lower()
    jd_skills = {kw for kw in SKILL_KEYWORDS if kw in jd_lower}
    cand_skills = set(candidate_skills)

    score = round(100 * len(jd_skills & cand_skills) / len(jd_skills)) if jd_skills else 0

    if score >= 80:
        status = "Shortlisted"
    elif score >= 60:
        status = "On Hold"
    else:
        status = "Rejected"

    return {
        "jd_match_score": score,
        "status": status,
        "matched_skills": sorted(jd_skills & cand_skills),
        "missing_skills": sorted(jd_skills - cand_skills),
    }


# ------------------------------------------------------------------
# 3. Scheduling Agent
# ------------------------------------------------------------------

def propose_interview_slot(preferred_time: str | None = None) -> dict:
    """Mock calendar lookup — in production this would call a real
    Calendar API (Google Calendar / Outlook) to check availability."""
    if preferred_time:
        slot = preferred_time
    else:
        base = dt.datetime.now() + dt.timedelta(days=random.randint(2, 5))
        base = base.replace(hour=random.choice([10, 11, 14, 15]), minute=0)
        slot = base.strftime("%d %b %Y, %I:%M %p")

    panel = random.choice(["Engineering Team", "Product & Engineering Panel", "Tech Lead Panel"])
    return {"scheduled_time": slot, "panel": panel, "status": "Scheduled"}


# ------------------------------------------------------------------
# 4. Communication Agent (FAQ chatbot)
# ------------------------------------------------------------------

def chatbot_reply(message: str, candidate_status: str | None = None) -> str:
    msg_lower = message.lower()

    if candidate_status and any(w in msg_lower for w in ["status", "application"]):
        return f"Thanks for checking in! Your current status is: **{candidate_status}**."

    best, best_hits = None, 0
    for entry in FAQ_KB:
        hits = sum(1 for kw in entry["q"] if kw in msg_lower)
        if hits > best_hits:
            best, best_hits = entry, hits

    if best:
        return best["a"]
    return ("I don't have that information yet — I've flagged this for the "
            "HR team and they'll follow up with you directly.")
